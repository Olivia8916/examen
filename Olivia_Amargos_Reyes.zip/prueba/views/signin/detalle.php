<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Prueba</title>
</head>
<body>
<?php require 'views/header.php';  ?>

<div id="main">
    <h1 class="center">Usuario logueado</h1>
    <div class="jumbotron">
        <div class="center" style="color:red"><?php echo $this->mensaje; ?></div>
    <form action="<?php echo constant('URL');?>signin/cerrarSesion" method="POST">
        <br>
        <p align="center">
            <input class="btn btn-danger btn-lg" type="submit" value="Cerrar Sesion">
        </p>
    </form>
    </div>
</div>
</div>

<?php require 'views/footer.php';  ?>
</body>
</html>