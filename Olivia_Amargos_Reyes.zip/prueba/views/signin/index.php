<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Prueba</title>
</head>
<body>
<?php require 'views/header.php';  ?>

<div id="main">
    <h1 class="center">Sección de Login</h1>

    <div class="center"><?php echo $this->mensaje; ?></div>
    <div class="container">
        <div class="jumbotron">
    <form action="<?php echo constant('URL');?>signin/loginUsuario" method="POST">
        <p>
            <label for="email">Email</label><br>
            <input type="email" name="email" id="text" required>
        </p>
        <p>
            <label for="password">Password</label><br>
            <input type="password" name="password" id="text" required>
        </p>
        <p>
            <input class="btn btn-danger btn-lg" type="submit" value="Login">
        </p>
    </form>
        </div>
    </div>
</div>

<?php require 'views/footer.php';  ?>
</body>
</html>