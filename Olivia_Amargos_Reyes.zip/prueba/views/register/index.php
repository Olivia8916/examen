<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Prueba</title>
    <script src="<?php echo constant('URL');?>public/js/js.js">
    </script>
</head>
<body>
<?php require 'views/header.php';  ?>

<div id="main">
    <h1 class="center">Sección de Registro</h1>

    <div class="container">
        <div class="jumbotron">
            <div class="center" style="color:red"><?php echo $this->mensaje; ?></div>
    <form id="formulario" onSubmit="return validarPasswd()" action="<?php echo constant('URL');?>register/registrarUsuario" method="POST">
        <p>
            <label for="email">Email</label><br>
            <input type="email" name="email" id="email" required>
        </p>
        <p>
            <label for="password">Password</label><br>
            <input type="password" name="password" id="password" required>
        </p>
        <p>
            <input class="btn btn-danger btn-lg" type="submit" value="Registrar nuevo usuario">
        </p>
    </form>
        </div>
    </div>
</div>

<?php require 'views/footer.php';  ?>
</body>
</html>