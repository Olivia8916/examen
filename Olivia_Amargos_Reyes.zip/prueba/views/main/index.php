<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <title>Prueba</title>
</head>
<body>
    <?php require 'views/header.php';  ?>

    <div id="main">
        <h1 class="center">Bienvenido al sitio</h1>
    </div>

    <div class="container">
        <div class="jumbotron">
            <div class="center" style="color:red"><?php echo $this->mensaje; ?></div>
            <h1 class="display-4">Sitio para registrarse!</h1>

            <p class="lead">En este sitio puede regitrarse, loguearse y cambiar la contraseña.</p>
            <hr class="my-4">
            <p>Regístrese aquí.</p>
            <p class="lead">
                <a class="btn btn-danger btn-lg" href="<?php echo constant('URL');?>register" role="button">Registrarse</a>
            </p>
        </div>
    </div>

    <?php require 'views/footer.php';  ?>

</body>
</html>