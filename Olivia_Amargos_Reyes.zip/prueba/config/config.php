<?php

define('URL','http://prueba/');

define('HOST', 'localhost');
define('DB', 'test');
define('USER', 'root');
define('PASSWORD','');
define('CHARSET', 'utf8mb4');

?>