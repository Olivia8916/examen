<?php

class User{

    public $email;
    public $password;


}

?>