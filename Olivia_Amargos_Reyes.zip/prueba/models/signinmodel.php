<?php
include_once 'models/user.php';

class SigninModel extends Model{

    public function __construct()
    {
        parent::__construct();
    }

     public function getByEmailPassword($datos)
    {
        $item=new User();
        $query=$this->db->connect()->prepare("SELECT*FROM users WHERE email= :email and password = :password");
        try {
            $query->execute([
                'email'=>$datos['email'],
                'password'=>$datos['password']
            ]);
            while ($row=$query->fetch()){
                $item->email=$row['email'];
                $item->password=$row['password'];
            }
            return $item;
        }catch (PDOException $e){
            return null;
        }
    }
}
?>