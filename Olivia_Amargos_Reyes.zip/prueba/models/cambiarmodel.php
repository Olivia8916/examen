<?php
include_once 'models/user.php';

class CambiarModel extends Model{

    public function __construct()
    {
        parent::__construct();
    }

    public function update($item)
    {
        $query=$this->db->connect()->prepare("UPDATE users SET password= :password WHERE email=:email");
        try {
            $query->execute([
                'password'=>$item['password'],
                'email'=>$item['email']
            ]);
            return true;

        }catch (PDOException $e){
            return false;
        }
    }
}
?>