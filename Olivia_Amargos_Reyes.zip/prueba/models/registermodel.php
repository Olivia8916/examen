<?php

class RegisterModel extends Model{

    public function __construct()
    {
        parent::__construct();
    }

    public function insert($datos){
        //insertar datos en la BD
        try {
            $existe_usuario = $this->getByEmail($datos['email']);

            if(!$existe_usuario) {
                $query = $this->db->connect()->prepare('INSERT INTO USERS(EMAIL,PASSWORD) VALUES(:email,:password)');
                $query->execute(['email' => $datos['email'], 'password' => $datos['password']]);
                return true;
            }
            else
            {
                return false;
            }
        }
        catch (PDOException $e){
            return false;
        }
    }
    public function getByEmail($email)
    {
        try{
            $query=$this->db->connect()->prepare("SELECT*FROM users WHERE email= :email");
            $query->execute(['email'=>$email]);
            $entro = false;
            while ($row=$query->fetch()){
                $entro=true;
            }
            if($entro)
                return true;
            else
                return false;
        }catch (PDOException $e){
            return null;
        }
    }

}
?>