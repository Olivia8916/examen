<?php

class Cambiar extends Controller {

    function __construct(){
        parent::__construct();
        $this->view->mensaje="";
        $this->view->usuarioemail="";
        session_start();
         if(isset($_SESSION['email'])) {
             $this->view->usuarioemail=$_SESSION['email'];
         }
    }

    function render()
    {
        $this->view->render('cambiar/index');
    }

    function changePassword(){
        //session_start();
        if(isset($_SESSION['email'])) {
            $email = $_SESSION['email'];
            $password = $_POST['password'];

            if ($this->model->update(['email' => $email, 'password' => $password])) {
                $usuario = new User();
                $usuario->email = $email;
                $usuario->password = $password;

                $this->view->usuario = $usuario;
                $this->view->mensaje = "Usuario actualizado correctamente.";

                unset($_SESSION['email']);
                $this->view->render('main/index');
            } else {
                $this->view->mensaje = "No se pudo actualizar el usuario.";
            }
        }
        else{
            $this->view->mensaje = "Debe loguearse primero.";
            $this->view->render('register/index');
        }

    }
}

?>
