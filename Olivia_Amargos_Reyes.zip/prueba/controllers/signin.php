<?php

class Signin extends Controller {

    function __construct(){
        parent::__construct();
        $this->view->mensaje="";
    }

    function render()
    {
        $this->view->render('signin/index');
    }

    function loginUsuario(){
        $email = $_POST['email'];
        $password = $_POST['password'];

        $usuario=$this->model->getByEmailPassword(['email'=>$email,'password'=>$password]);

        if(isset($usuario->email))
        {
            session_start();
            $_SESSION['email']=$usuario->email;
            $this->view->usuario=$usuario;
            $this->view->mensaje="Hola: $usuario->email. Bienvenido de nuevo.";
            $this->view->render('signin/detalle');
        }
        else
        {
            $this->view->mensaje="El usuario no existe o la contraseña es incorrecta.";
            $this->view->render('signin/index');
        }

    }

    function cerrarSesion(){
        session_start();
        unset($_SESSION['email']);

        $this->view->mensaje="Sesión cerrada.";
        $this->view->render('main/index');
    }
}

?>
