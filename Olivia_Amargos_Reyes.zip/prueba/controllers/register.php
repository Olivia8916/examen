<?php

class Register extends Controller {

    function __construct(){
        parent::__construct();
        $this->view->mensaje="";
    }

    function render()
    {
        $this->view->render('register/index');
    }

    function registrarUsuario(){
        $email = $_POST['email'];
        $password = $_POST['password'];

        $mensaje="";
        if($this->model->insert(['email'=>$email,'password'=>$password]))
        {
            $mensaje= "Nuevo usuario creado";
        }
        else{
            $mensaje= "El usuario ya existe.";
        }

        $this->view->mensaje=$mensaje;
        $this->render();
    }
}

?>