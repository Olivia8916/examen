
function validarPasswd() {
    var password = document.getElementById("password").value;
    if(password.length <= 6 || password.length>20) {
        alert('La contraseña debe tener mas de 6 y menos de 20 digitos.');
        return false;
    }
}
